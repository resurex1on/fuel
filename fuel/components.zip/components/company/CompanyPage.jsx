import { useEffect, useState } from 'react';
import { Text, View, Picker, StyleSheet, TextInput } from 'react-native';
import { UnitSelect } from '../unitSelect/unitSelect';

export const CompanyPage = () => {
  const [fuelUsed, setFuelUsed] = useState(0);
  const [distance, setDistance] = useState(0);
  const [fuelCost, setFuelCost] = useState(0);
  const [fuelConsumption, setFuelConsumption] = useState(0);
  const [kmCost, setKmCost] = useState(0);

  useEffect(() => {
    if (!fuelUsed || !distance) {
      return
    }

    const fuelConsumptionPerKm = (fuelUsed / distance)
    const _fuelConsumption = fuelConsumptionPerKm * 100
    setFuelConsumption(_fuelConsumption)

    if (fuelCost) {
      setKmCost(fuelConsumptionPerKm * fuelCost)
    }
  }, [fuelUsed, distance, fuelCost])

  return (
    <View style={styles.company}>
     
    </View>
  );
}

const styles = StyleSheet.create({
  title: {
    fontWeight: 600,
  },
  company: {
    display: "grid",
    gap: "12px"
  },
  line: {
    borderBottomColor: 'gray',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  row: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
    gap: "12px"
  },
  input: {
    border: "1px solid gray"
  },
  column: {
    gap: "12px",
    minWidth: "400px"
  }
});